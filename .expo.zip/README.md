# ceryletech-react-native-apk

A React Native mobile application built with Expo for task management and project tracking.

## Features

- User Authentication (Login/Register)
- Task Management
- Project Selection with Search
- Date Picker for Due Dates
- Status and Priority Management
- Task Details and Editing
- Real-time Updates

## Tech Stack

- React Native
- Expo
- React Native Paper (UI Components)
- React Navigation
- Axios (API calls)
- React Native DateTimePicker

## Installation

1. Clone the repository
```bash
git clone https://github.com/vishwas-work/ceryletech-react-native-apk.git
cd ceryletech-react-native-apk
```

2. Install dependencies
```bash
npm install
```

3. Start the development server
```bash
npm start
```

## Build

To build the APK:
```bash
npx eas build --platform android
```

## Configuration

Update the backend URL in `app.config.js`:
```javascript
backendUrl: "your-backend-url-here"
```#   p d f r o n t E n d  
 #   p d f r o n t E n d  
 # pdfrontEnd 
